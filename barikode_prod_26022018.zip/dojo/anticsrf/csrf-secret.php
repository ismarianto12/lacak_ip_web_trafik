<?php $secret = md5(__DIR__);
